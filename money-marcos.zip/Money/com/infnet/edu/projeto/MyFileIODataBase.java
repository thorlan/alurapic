package com.infnet.edu.projeto;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;


public class MyFileIODataBase {

	private final static String ACCOUNT_FILE = "Accounts.txt";
	
	public void persist(List<Conta> contas) {
		
		try (FileOutputStream fos = new FileOutputStream(ACCOUNT_FILE); ObjectOutputStream oos = new ObjectOutputStream(fos)){
			oos.writeObject(contas);
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<Conta> getContas() throws  ClassNotFoundException{
		
		List<Conta> contas = null;
		
		try (FileInputStream fin= new FileInputStream (ACCOUNT_FILE)){
			if (fin.available() > 0) {
				ObjectInputStream ois = new ObjectInputStream(fin);
				contas= (ArrayList<Conta>) ois.readObject();
			} else {
				contas = new ArrayList<>();
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return contas;
	}
}
