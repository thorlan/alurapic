package com.infnet.edu.projeto;
//ConsultaSaldo.java

public class ConsultaSaldo extends Transacao {

	public ConsultaSaldo (int userAccountNumber, Tela atmScreen, BankDatabase atmBankDatabase) {
		super(userAccountNumber, atmScreen, atmBankDatabase);
	}
	
	@Override
	public void execute() {
		BankDatabase bankDatabase = getBankDatabase();
		Tela screen = getScreen();

		double availableBalance = bankDatabase.getSaldoDisponivel(getAccountNumber());
		
		double totalBalance = bankDatabase.getSaldoTotal(getAccountNumber());
		
		screen.displayLinhaMensagem("\nBalance Information:");
		screen.displayMensagem(" - Available balance: ");
		screen.displayMontante(availableBalance);
		screen.displayMensagem("\n - Total balance:");
		screen.displayMontante(totalBalance);
		screen.displayLinhaMensagem("");
	}
}
