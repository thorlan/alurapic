package com.infnet.edu.projeto;
//Tela.java

public class Tela {
	public void displayMensagem(String mensagem) {
		System.out.print(mensagem);
	}
	
	public void displayLinhaMensagem(String mensagem) {
		System.out.println(mensagem);
	}
	
	public void displayMontante(double montante) {
		System.out.printf("$%,.2f", montante);
	}
}