package com.infnet.edu.projeto;
// Projeto de Bloco - SistemaATM.java
// Classe Principal do ATM

public class SistemaATM {
	public static void main(String[] args) {
		ATM novoATM = new ATM();
		novoATM.execute();
	}
}
