package com.infnet.edu.projeto;
//ATM.java
public class ATM {
	private boolean usuarioAutenticado; // verifica se o usuario est� autenticado
	private int numeroContaCorrente; // Numero da conta do usuario corrente
	private Tela screen; // Tela do ATM
	private Teclado keypad; // Teclado do ATM
	private CashDispenser cashDispenser; // Fornecedor de C�dulas do ATM
	private DepositSlot depositSlot; // Coletor de Depositos do ATM
	private BankDatabase bankDatabase; // Banco de Dados do Banco Money
	
	// Constantes do Menu de Op��es
	private static final int CONSULTARSALDO = 1;
	private static final int DEPOSITAR = 2;
	private static final int SACAR = 3;
	private static final int SAIR = 4;
	
	public ATM() {
		usuarioAutenticado = false;
		numeroContaCorrente = 0;
		screen = new Tela();
		keypad = new Teclado();
		cashDispenser = new CashDispenser();
		depositSlot = new DepositSlot();
		bankDatabase = BankDatabase.getInstance();
	}
	
	public void execute() {

		while (true) {
			while (!usuarioAutenticado) {
				screen.displayLinhaMensagem("\nBem Vindo!");
				autenticaUsuario();
			}
			
			realizaTransacao();
			usuarioAutenticado = false;
			numeroContaCorrente = 0;
			screen.displayLinhaMensagem("\nObrigado!");
		}
	}
	
	public void autenticaUsuario() {
		screen.displayMensagem("\nPor favor, entre o numero de sua conta: ");
		int accountNumber = keypad.getInput();
		screen.displayMensagem("\nPor favor, entre com seu PIN: ");
		int pin = keypad.getInput();
		
		usuarioAutenticado = bankDatabase.usuarioAutenticado(accountNumber, pin);
		
		// verifica se o usu�rio foi autenticado com sucesso
		if (usuarioAutenticado) {
			numeroContaCorrente = accountNumber; 
		} else {
			screen.displayMensagem("\nO numero de conta ou PIN informados � inv�lido. Favor tentar novamente.");
		}
	}
		
		private void realizaTransacao() {
			
			Transacao currentTransaction = null;
			
			boolean userExited = false;
			
			while (!userExited) {

				int mainMenuSelection = displayMainMenu();
				
				switch (mainMenuSelection) {
				case CONSULTARSALDO:
				case DEPOSITAR:
				case SACAR:
					currentTransaction = criaTransacao(mainMenuSelection);
					currentTransaction.execute();
					break;
				case SAIR:
					screen.displayMensagem("\nSaindo do Sistema...");
					userExited = true;
					break;
				default: 
					screen.displayMensagem("\n Voc� N�O digitou uma op��o v�lida. Tente novamente.");
					break;
				}
			}
		}
		
		private int displayMainMenu() {
			screen.displayLinhaMensagem("\nMenu Principal:");
			screen.displayLinhaMensagem("1 - Verificar Saldo");
			screen.displayLinhaMensagem("2 - Realizar Deposito");
			screen.displayLinhaMensagem("3 - Realizar Saque");
			screen.displayLinhaMensagem("4 - Sair\n");
			return keypad.getInput();
		}
		
		private Transacao criaTransacao(int type) {
			Transacao tmp = null;
			
			switch (type) {
			case CONSULTARSALDO:
				tmp = new ConsultaSaldo(numeroContaCorrente, screen, bankDatabase);
				break;
			case DEPOSITAR:
				tmp = new Deposito(numeroContaCorrente, screen, bankDatabase, keypad, depositSlot);
				break;
			case SACAR:
				tmp = new Saque(numeroContaCorrente, screen, bankDatabase, keypad, cashDispenser);
				break;
			}
			return tmp;
		}
}