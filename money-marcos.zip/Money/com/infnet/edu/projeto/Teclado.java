package com.infnet.edu.projeto;
//Teclado.java

import java.util.Scanner;

public class Teclado {
	private Scanner input;
	
	public Teclado() {
		input = new Scanner(System.in);
	}
	
	public int getInput() {
		return input.nextInt();
	}
}