package com.infnet.edu.projeto;
public class CashDispenser {

	public final static int CONTADOR_INICIAL = 500;
	private int contador;
	
	public CashDispenser() {
		contador = CONTADOR_INICIAL;
	}
	
	public void dispenseCash(int montante) {
		int valorSolicitado = montante / 20;
		contador -= valorSolicitado;
	}
	
	public boolean isSufficientCashAvailable(int montante) {
		int valorSolicitado = montante / 20;
		
		if (contador >= valorSolicitado)
			return true;
		else
			return false;
	}
}