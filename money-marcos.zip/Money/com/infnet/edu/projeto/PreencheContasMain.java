package com.infnet.edu.projeto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PreencheContasMain {

	public static void main(String[] args) {
		Conta c1 = new Conta(12340, 54320, 1000.00, 1200.00);
		Conta c2 = new Conta(12341,54321,1001.00,1201.00);
		Conta c3 = new Conta(12342,54322,1002.00,1202.00);
		Conta c4 = new Conta(12343,54323,1003.00,1203.00);
		Conta c5 = new Conta(12344,54324,1004.00,1204.00);
		Conta c6 = new Conta(12345,54321,1005.00,1205.00);
		Conta c7 = new Conta(12346,54326,1006.00,1206.00);
		Conta c8 = new Conta(12347,54327,1007.00,1207.00);
		
		
		List<Conta> contas = new ArrayList<>();
		
		contas.add(c1);
		contas.add(c2);
		contas.add(c3);
		contas.add(c4);
		contas.add(c5);
		contas.add(c6);
		contas.add(c7);
		contas.add(c8);
		
		MyFileIODataBase fileIo = new MyFileIODataBase();
		fileIo.persist(contas);
		
		
		
		
		
		
	}
}
