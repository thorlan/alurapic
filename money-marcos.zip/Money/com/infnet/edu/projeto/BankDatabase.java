package com.infnet.edu.projeto;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BankDatabase {
	
	private static List<Conta> contas;
	
	private static BankDatabase dataBaseSingleton;
	private MyFileIODataBase persistencia;
	
	private BankDatabase() {
		persistencia = new MyFileIODataBase();
		contas = new ArrayList<>();
		leAccountsTxt();
	}
	
	private void leAccountsTxt() {
		try {
			contas = persistencia.getContas();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private Conta getConta(int numeroConta) {
		for (Conta contaAtual : contas) {
				if (contaAtual.getNumeroConta() == numeroConta)
					return contaAtual;
				}
			return null;
		}
	
	public static synchronized BankDatabase getInstance() {
		if (dataBaseSingleton == null) {
			dataBaseSingleton = new BankDatabase();
		}
		return dataBaseSingleton;
	}
	
	public boolean usuarioAutenticado(int numeroContaUsuario, int usuarioPin) {
		Conta usuarioConta = getConta(numeroContaUsuario);
		
		if (usuarioConta != null) {
			return usuarioConta.validaPIN(usuarioPin);
		} else {
			return false;
		}
	}
	
	public double getSaldoDisponivel(int numeroContaUsuario) {
		return getConta(numeroContaUsuario).getSaldoDisponivel();
	}
	
	public double getSaldoTotal(int numeroContaUsuario) {
		return getConta(numeroContaUsuario).getSaldoDisponivel();
	}
	
	public void credito(int numeroContaUsuario, double montante) {
		getConta(numeroContaUsuario).credito(montante);
		persistencia.persist(contas);
	}
	
	public void debito(int numeroContaUsuario, double montante) {
		getConta(numeroContaUsuario).debito(montante);
		persistencia.persist(contas);
	}
}
